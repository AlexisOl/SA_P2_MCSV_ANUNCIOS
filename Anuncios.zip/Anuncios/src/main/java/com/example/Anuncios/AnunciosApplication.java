package com.example.Anuncios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnunciosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnunciosApplication.class, args);
	}

}
