package com.example.Anuncios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnunciosApplicationTests {

	@Test
	void contextLoads() {
	}

}
